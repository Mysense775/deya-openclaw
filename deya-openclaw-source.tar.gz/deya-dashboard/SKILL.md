---
name: deya-dashboard
description: Web dashboard for managing OpenClaw instance. Use when user needs a web interface to control agent, view memory, manage skills, and monitor tasks.
triggers:
  - "веб интерфейс"
  - "дашборд"
  - "dashboard"
  - "веб управление"
  - "web ui"
  - "панель управления"
---

# Deya Dashboard 🎛️

Веб-интерфейс для управления OpenClaw инстансом.

## Быстрый старт

```bash
# Установка
cd skills/deya-dashboard
pip install -r requirements.txt

# Запуск
python main.py

# Открыть в браузере
# http://localhost:8001
```

## Возможности

### 1. Чат с Деей 💬
- WebSocket для real-time общения
- История сообщений
- Быстрые действия (кнопки)
- Typing indicator

### 2. Дашборд 📊
- Статистика инстанса
- График активности
- System health (CPU, RAM)
- Последние действия

### 3. Управление скиллами 🛠️
- Список установленных скиллов
- Установка новых (.skill файлы)
- Удаление скиллов
- Просмотр описаний

### 4. Память 🧠
- Просмотр MEMORY.md
- Дневники по датам
- Поиск по памяти
- Редактирование

### 5. Каналы 📢
- Telegram интеграция
- Список постов
- Создание новых постов
- Статистика канала

### 6. Задачи ⏰
- Cron-джобы
- Background tasks
- Логи выполнения
- Добавление/удаление задач

### 7. Настройки ⚙️
- Конфигурация модели
- API ключи
- Часовой пояс
- Безопасность (пароль)

## Структура

```
deya-dashboard/
├── main.py              # FastAPI приложение
├── templates/           # Jinja2 шаблоны
│   ├── base.html        # Базовый шаблон с sidebar
│   ├── index.html       # Чат с Деей
│   ├── dashboard.html   # Дашборд со статистикой
│   ├── skills.html      # Управление скиллами
│   ├── memory.html      # Просмотр памяти
│   ├── channels.html    # Telegram каналы
│   ├── tasks.html       # Cron задачи
│   └── settings.html    # Настройки
├── static/              # CSS, JS
│   ├── css/
│   └── js/
└── requirements.txt
```

## Технологии

- **Backend:** FastAPI
- **Frontend:** Jinja2 + Tailwind CSS + Alpine.js
- **Real-time:** WebSocket для чата
- **Mobile:** Адаптивный дизайн (mobile-first)

## Особенности дизайна

- 🌺 **Deya branding:** градиент заката, мягкие формы
- 🌙 **Тёмная тема:** как в AI Router
- 📱 **Mobile-first:** работает на телефоне
- ⚡ **Быстрый:** HTMX + Alpine.js, нет React

## API Endpoints

```
GET  /              - Главная (чат)
GET  /dashboard     - Дашборд
GET  /skills        - Список скиллов
POST /api/skills/install - Установить скилл
GET  /memory        - Просмотр памяти
GET  /api/memory/{file} - Получить файл
GET  /channels      - Каналы
GET  /tasks         - Задачи
GET  /settings      - Настройки
WS   /ws/chat       - WebSocket чат
```

## Интеграция с OpenClaw

Дашборд работает с:
- Памятью (чтение/запись MD файлов)
- Скиллами (установка/удаление)
- Кроном (чтение и управление задачами)
- Каналами (через API Telegram бота)

## Безопасность

- Basic Auth или JWT для доступа
- CSRF защита
- Ограничение команд (whitelist)
- Логирование действий

## Roadmap

- [x] Базовая структура FastAPI
- [x] Шаблоны с Tailwind + Alpine
- [x] Чат с WebSocket
- [x] Sidebar навигация
- [ ] Дашборд со статистикой
- [ ] Управление скиллами
- [ ] Просмотр памяти
- [ ] Интеграция с Telegram
- [ ] Cron задачи
- [ ] Настройки
- [ ] Авторизация
