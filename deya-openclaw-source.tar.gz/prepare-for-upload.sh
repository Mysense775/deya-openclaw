#!/bin/bash
# Alternative: Create a complete archive for manual upload

cd /root/.openclaw/workspace/skills

echo "📦 СОЗДАНИЕ АРХИВА ДЛЯ GITHUB..."

# Create clean archive without .git
mkdir -p /tmp/deya-upload
cp -r . /tmp/deya-upload/
cd /tmp/deya-upload
rm -rf .git
rm -rf release-v1.0
rm -f *.tar.gz

# Create ZIP for easy upload
zip -r /root/.openclaw/workspace/skills/deya-openclaw-source.zip .

echo ""
echo "✅ Архив создан: deya-openclaw-source.zip"
echo ""
echo "🚀 ЗАГРУЗКА НА GITHUB:"
echo ""
echo "1. Открой: https://github.com/new"
echo "2. Repository name: deya-openclaw"
echo "3. Description: Полный инстанс OpenClaw с веб-интерфейсом и персоной Деи"
echo "4. Public ✅"
echo "5. НЕ создавай README, .gitignore, license"
echo "6. Create repository"
echo ""
echo "7. На странице репозитория нажми 'uploading an existing file'"
echo "8. Выбери или перетащи: deya-openclaw-source.zip"
echo "9. Commit changes"
echo ""
echo "10. Перейди в Releases → Create new release"
echo "11. Tag: v1.0.0"
echo "12. Title: 🌺 Deya OpenClaw v1.0"
echo "13. Загрузи: deya-openclaw-v1.0.tar.gz"
echo "14. Publish release"
echo ""
echo "🔗 После этого будет доступно:"
echo "   https://github.com/Mysense775/deya-openclaw"
