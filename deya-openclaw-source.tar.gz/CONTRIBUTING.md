# Contributing to Deya OpenClaw Instance

Спасибо за интерес к проекту! Вот как можно помочь:

## 🐛 Сообщение об ошибках

1. Проверьте, нет ли уже такого issue
2. Создайте новый issue с тегом `bug`
3. Опишите:
   - Что ожидалось
   - Что произошло
   - Как воспроизвести
   - Логи (если есть)

## 💡 Предложения

1. Создайте issue с тегом `enhancement`
2. Опишите идею и use case
3. Обсудим реализацию

## 🔧 Pull Requests

### Создание нового скилла

```bash
# 1. Fork репозитория
# 2. Клонировать
git clone https://github.com/YOUR_USERNAME/deya-openclaw.git

# 3. Создать ветку
git checkout -b feature/my-skill

# 4. Создать структуру скилла
mkdir skills/my-skill
cat > skills/my-skill/SKILL.md << 'EOF'
---
name: my-skill
description: Краткое описание
triggers:
  - "ключевое слово"
---

# My Skill

## Описание
Что делает этот скилл

## Использование
Примеры

## API
Если есть
EOF

# 5. Добавить код
# scripts/
# assets/
# references/

# 6. Упаковать
tar -czf my-skill-v1.0.skill my-skill/

# 7. Коммит
git add .
git commit -m "Add my-skill v1.0"
git push origin feature/my-skill

# 8. Создать PR
```

### Требования к скиллам

- [ ] SKILL.md с описанием
- [ ] Чёткие триггеры (triggers)
- [ ] Документация использования
- [ ] Примеры
- [ ] requirements.txt (если нужно)

### Структура скилла

```
skill-name/
├── SKILL.md           # Обязательно
├── README.md          # Дополнительно
├── scripts/           # Python/bash скрипты
├── assets/            # Компоненты, изображения
└── references/        # Документация
```

### Стиль кода

- Python: PEP 8
- Bash: shellcheck
- Комментарии на русском или английском
- Функции с docstrings

## 🧪 Тестирование

```bash
# Установить локально
./install.sh

# Запустить
~/.openclaw/start-deya.sh

# Проверить
open http://localhost:8001
```

## 📋 Чеклист PR

- [ ] Код работает
- [ ] Тесты пройдены (если есть)
- [ ] Документация обновлена
- [ ] CHANGELOG.md обновлён
- [ ] Коммиты понятные

## 🏷️ Версионирование

Используем [SemVer](https://semver.org/):
- MAJOR — ломающие изменения
- MINOR — новые фичи
- PATCH — багфиксы

## 💬 Связь

- GitHub Issues
- Telegram: @dayanrouter

## 🌺 Code of Conduct

- Будьте вежливы
- Уважайте разные мнения
- Конструктивная критика
- Фокус на качестве

Спасибо за вклад!
