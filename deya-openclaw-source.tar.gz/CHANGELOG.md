# Changelog

Все значимые изменения проекта будут документироваться здесь.

Формат основан на [Keep a Changelog](https://keepachangelog.com/ru/1.0.0/),
и проект придерживается [Semantic Versioning](https://semver.org/lang/ru/).

## [1.0.0] - 2026-02-27

### 🌺 Добавлено

- **deya-mode v1.0** — Персона Деи (дух-хранитель с Бали)
  - Полное описание персоны
  - Скрипты активации и проверки
  - Примеры диалогов
  - Временные фазы (утро/день/вечер/ночь)
  - Детектор настроения
  - Интеграция с RAG

- **ui-ux-pro-max v1.1** — UI генератор
  - Генератор React-компонентов
  - 4 стандартных компонента (Button, Card, Input, Badge)
  - 3 GSAP компонента с анимациями
  - Canvas preview
  - Гайд по стилю Деи

- **code-ninja v1.0** — Инструменты разработчика
  - architecture-analyzer.py
  - debug-detective.py
  - refactor-suggest.py
  - multi-lang-switch.py

- **web-hunter v1.0** — Web scraping
  - search-aggregator.py
  - dynamic-parser.py
  - fact-checker.py
  - email-finder.py
  - price-monitor.py

- **deya-visual-identity v1.0** — Визуальная айдентика
  - Подробное описание внешности
  - Сезонные параметры
  - Скрипт генерации изображений

- **deya-dashboard v1.0** — Веб-интерфейс
  - 7 страниц (чат, дашборд, скиллы, память, каналы, задачи, настройки)
  - FastAPI + WebSocket
  - Tailwind CSS + Alpine.js
  - Mobile-first дизайн

### 🚀 Инфраструктура

- One-line installer (`install-deya.sh`)
- Docker образ и docker-compose
- GitHub Actions workflow для релизов
- Полная документация
- MIT License

### 📦 Релиз

- GitHub: https://github.com/Mysense775/deya-openclaw
- Размер: 747 KB (tar.gz)
- Docker: `deya/openclaw:1.0.0`

---

## [Unreleased]

### Планируется

- [ ] Авторизация (JWT)
- [ ] Многопользовательский режим
- [ ] Интеграция с Discord
- [ ] Интеграция с Slack
- [ ] Мобильное приложение
- [ ] Больше AI моделей
- [ ] Marketplace скиллов
