# Changelog Code-Ninja

## [1.0.0] - 2025-02-26

### Added
- `architecture-analyzer.py` — анализ структуры проекта
  - Поиск циклических импортов
  - Обнаружение больших файлов (>500 строк)
  - Подсчёт цикломатической сложности
  - Архитектурные "запахи" (utils.py, god classes)
  - Генерация JSON отчёта
  
- `debug-detective.py` — интеллектуальный поиск ошибок
  - База знаний 15+ типовых ошибок
  - Анализ traceback с контекстом
  - Конкретные решения для каждой ошибки
  - Severity levels (critical/high/medium/low)
  
- `refactor-suggest.py` — рекомендации по улучшению
  - Обнаружение длинных функций
  - Проверка вложенности циклов
  - Поиск магических чисел
  - Проверка bare except
  - Рекомендации по структуре
  
- `multi-lang-switch.py` — переключение между языками
  - Python 🐍, JavaScript 💛, TypeScript 💙, Go 🐹
  - 11 паттернов (async, error handling, classes, etc.)
  - Перевод с одного языка на другой
  - Советы по переходу

### Documentation
- SKILL.md — workflow и примеры использования
- README.md — полная документация
- CHANGELOG.md — история изменений

## Готово к использованию! 🥷
