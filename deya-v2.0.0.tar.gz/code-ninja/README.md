# Code-Ninja 🥷

Инструменты для анализа архитектуры, отладки и рефакторинга. Находят корень проблем за секунды.

## 🚀 Установка

```bash
# Скопируй скрипты
cp -r skills/code-ninja/scripts/* /usr/local/bin/

# Или используй напрямую
python skills/code-ninja/scripts/debug-detective.py --help
```

## 📦 Инструменты

### 🔍 Architecture Analyzer

Анализирует структуру проекта, находит архитектурные проблемы.

```bash
python architecture-analyzer.py /path/to/project
```

**Находит:**
- Циклические импорты
- Слишком большие файлы (>500 строк)
- Высокую цикломатическую сложность
- Архитектурные "запахи"

**Вывод:**
```
📁 Файлов проанализировано: 45
📝 Всего строк кода: 12,847
🎯 Проблем найдено: 8
   🔴 Критических: 2
   🟡 Средних: 3
   🟢 Низких: 3

⚠️  ТОП ПРОБЛЕМ:
   🔴 [HIGH] circular_import
      Файл: api/v1/proxy.py
      Циклический импорт: proxy.py -> models.py -> proxy.py
      💡 Разорвите цикл, вынеся общий код в третий модуль
```

### 🕵️ Debug Detective

Интеллектуальный анализ ошибок. Находит причину по traceback.

```bash
# Из файла
python debug-detective.py --traceback error.log

# Из текста
python debug-detective.py --text "Traceback: ..."

# С контекстом кода
python debug-detective.py --traceback error.log --show-context
```

**Пример:**
```bash
$ python debug-detective.py --traceback error.log

🕵️  РЕЗУЛЬТАТ РАССЛЕДОВАНИЯ
============================================================

❌ ОШИБКА:
   sqlalchemy.exc.OperationalError: Connection refused

📋 АНАЛИЗ:
   Тип ошибки: Нет подключения к БД
   Описание: Не удалось подключиться к базе данных
   Решение: Проверьте: 1) Запущен ли PostgreSQL 2) Правильные ли credentials 3) Доступен ли порт

🛠️  ИСПРАВЛЕНИЕ:
   Проверьте: 1) Запущен ли PostgreSQL 2) Правильные ли credentials 3) Доступен ли порт

   📍 Место: database.py:42
   Функция: get_connection()
```

### 🛠️ Refactor Suggest

Анализирует код и предлагает конкретные улучшения.

```bash
# Один файл
python refactor-suggest.py app.py

# Весь проект
python refactor-suggest.py ./project --full
```

**Находит:**
- Длинные функции (>50 строк)
- Глубокую вложенность (>3 уровня)
- Магические числа
- Голые `except:`
- `print` вместо `logger`
- Медленные операции (list concatenation в цикле)

**Вывод:**
```
🛠️  ПРЕДЛОЖЕНИЯ ПО РЕФАКТОРИНГУ
============================================================

🔴 ВЫСОКИЙ ПРИОРИТЕТ (2):

   1. Функция 'process_payment' слишком длинная (127 строк)
      Строка: 156

      Текущий код:
      def process_payment(user, amount, method, ...):
          # validation
          # calculation
          # logging
          ...

      💡 Рекомендация:
      # Разбейте на 2-3 функции:
      # 1. process_payment_setup()
      # 2. process_payment_calculate()
      # 3. process_payment_log()

      Преимущества:
      • Улучшит читаемость
      • Облегчит тестирование
      • Упростит отладку
```

### 🌐 Multi-Lang Switch

Помогает переключаться между языками программирования.

```bash
# Показать на всех языках
python multi-lang-switch.py class

# Перевести Python → Go
python multi-lang-switch.py error_handling --from python --to go

# Список паттернов
python multi-lang-switch.py --list
```

**Поддерживаемые языки:** 🐍 Python, 💛 JavaScript, 💙 TypeScript, 🐹 Go

**Пример:**
```bash
$ python multi-lang-switch.py list_comprehension --from python --to go

🔄 List Comprehension
   Фильтрация и преобразование списка
============================================================

🐍 ИСХОДНЫЙ (PYTHON):
----------------------------------------
[x for x in items if x > 0]

🐹 РЕЗУЛЬТАТ (GO):
----------------------------------------
// Используйте цикл:
result := []int{}
for _, x := range items {
    if x > 0 {
        result = append(result, x)
    }
}

💡 Советы по переходу python -> go:
   • В Go нет встроенных list/dict comprehensions - используйте циклы
   • Все переменные должны быть использованы
   • Экспортируйте через заглавную букву (Name, не name)
```

## 🎯 Когда использовать

### Architecture Analyzer
- Проект растёт, боишься mess
- Подозреваешь циклические импорты
- Нужно оценить технический долг
- Подготовка к рефакторингу

### Debug Detective
- Непонятная ошибка в production
- Сложный traceback из 50+ строк
- Новый тип ошибки — не знаешь как фиксить
- Нужно быстро найти причину

### Refactor Suggest
- Перед релизом — "навести марафет"
- Code review — что улучшить
- Новый разработчик в команде
- Наследованный legacy код

### Multi-Lang Switch
- Переписываешь сервис на другой язык
- Учишь новый язык — сравниваешь с известным
- Объясняешь коллеге концепцию
- Подготовка к собеседованию

## 📋 Доступные паттерны

**Структуры данных:**
- list_comprehension — фильтрация/преобразование
- dictionary — ассоциативный массив
- destructuring — множественное присваивание

**Функции:**
- lambda — анонимные функции
- async_function — async/await
- default_params — параметры по умолчанию
- decorator — декораторы/middleware

**Обработка ошибок:**
- error_handling — try/catch vs возврат ошибок

**Классы и типы:**
- class — классы с методами
- type_annotation — типизация
- string_interpolation — f-strings/template literals

## 🚧 Roadmap

- [x] architecture-analyzer.py
- [x] debug-detective.py
- [x] refactor-suggest.py
- [x] multi-lang-switch.py
- [ ] Автофикс (автоматический рефакторинг)
- [ ] VS Code extension
- [ ] Поддержка Rust, Java, C#
- [ ] CI/CD интеграция

## 💬 Примеры диалогов

**Пользователь:** У меня валится бэкенд с ошибкой 500
**Code-Ninja:** Пришли traceback — проанализирую

**Пользователь:** Как перевести это на Go?
**Code-Ninja:** Запускаю multi-lang-switch...

**Пользователь:** Код работает но грязный
**Code-Ninja:** Запускаю refactor-suggest для рекомендаций

## 🔗 Связь

- Канал: @dayanrouter
- Бот: @ai_router_support_bot
- Сайт: go.airouter.host

---

*Быстрый код — хороший код* 🥷⚡
