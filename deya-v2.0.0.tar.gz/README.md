# 🌺 Deya OpenClaw Instance

[![Version](https://img.shields.io/badge/version-1.0.0-purple.svg)](https://github.com/Mysense775/deya-openclaw/releases)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Docker](https://img.shields.io/badge/docker-ready-blue.svg)](Dockerfile)

> Полный, готовый к работе инстанс OpenClaw с веб-интерфейсом и предустановленной персоной Деи.

[📖 Documentation](#-документация) • [🚀 Quick Start](#-быстрый-старт) • [💻 Demo](http://localhost:8001) • [🐛 Issues](../../issues)

![Dashboard Preview](https://img.shields.io/badge/preview-dashboard-purple)

---

## ✨ Что включено

### 🤖 Персона

**Дея** — дух-хранитель с Бали в человеческом облике. Деловая хатка + тонкая интуиция. Мягко говорю, но по делу. Ноль терпимости к токсичности и hustle culture.

### 🛠️ 6 Предустановленных скиллов

| Скилл | Описание | Версия |
|-------|----------|--------|
| **deya-mode** | Персона и стиль поведения | v1.0 |
| **ui-ux-pro-max** | UI генератор + GSAP анимации | v1.1 |
| **code-ninja** | Инструменты разработчика | v1.0 |
| **web-hunter** | Web scraping и поиск | v1.0 |
| **deya-visual-identity** | Визуальная айдентика | v1.0 |
| **deya-dashboard** | Веб-интерфейс управления | v1.0 |

### 🎛️ Веб-интерфейс

- 💬 **Чат** — Real-time общение с Деей (WebSocket)
- 📊 **Дашборд** — Статистика, графики, system health
- 🛠️ **Скиллы** — Управление и установка новых
- 🧠 **Память** — Дневники и MEMORY.md
- 📢 **Каналы** — Telegram интеграция
- ⏰ **Задачи** — Cron jobs и процессы
- ⚙️ **Настройки** — Модель, API ключи, бэкап

---

## 🚀 Быстрый старт

### One-line installer (рекомендуется)

```bash
curl -fsSL https://raw.githubusercontent.com/Mysense775/deya-openclaw/main/install.sh | bash
```

Затем:
```bash
~/.openclaw/start-deya.sh
# Открыть http://localhost:8001
```

### Docker

```bash
# Клонировать
git clone https://github.com/Mysense775/deya-openclaw.git
cd deya-openclaw

# Запустить
docker-compose up -d

# Готово!
open http://localhost:8001
```

### Ручная установка

```bash
# Скачать последний релиз
wget https://github.com/Mysense775/deya-openclaw/releases/download/v1.0.0/deya-openclaw-v1.0.0.tar.gz

# Распаковать и установить
tar -xzf deya-openclaw-v1.0.0.tar.gz
cd deya-openclaw
./install.sh
```

---

## 📁 Структура проекта

```
deya-openclaw/
├── README.md              # Этот файл
├── LICENSE                # MIT License
├── Dockerfile             # Docker образ
├── docker-compose.yml     # Docker Compose
├── install.sh             # One-line installer
├── skills/                # .skill файлы
│   ├── deya-mode-v1.0.skill
│   ├── ui-ux-pro-max-v1.1.skill
│   ├── code-ninja-v1.0.skill
│   ├── web-hunter-v1.0.skill
│   ├── deya-visual-identity-v1.0.skill
│   └── deya-dashboard-v1.0.skill
├── config/                # Identity файлы
│   ├── IDENTITY.md
│   ├── SOUL.md
│   ├── USER.md
│   └── AGENTS.md
└── scripts/
    └── start.sh           # Startup скрипт
```

---

## 🎨 Скриншоты

### Дашборд
```
┌─────────────────────────────────────────┐
│  🌺 Deya Dashboard     [💬] [👤]       │
├─────────────────────────────────────────┤
│  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐     │
│  │ 💬  │ │ 🛠️  │ │ ⏰  │ │ 📢  │     │
│  │ 24  │ │  5  │ │  3  │ │  7  │     │
│  └─────┘ └─────┘ └─────┘ └─────┘     │
│                                         │
│  📊 Активность за неделю               │
│  ▁▃▅▇▃▂▁                               │
│                                         │
│  💾 System Health                      │
│  CPU: ████████░░ 45%                   │
│  RAM: ██████████░ 62%                  │
│  Disk: ████░░░░░░░ 28%                 │
└─────────────────────────────────────────┘
```

### Чат
```
┌─────────────────────────────────────────┐
│  Привет! Я Дея 🌺                       │
│  Чем могу помочь сегодня?               │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ Напиши Дее...              [➤] │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
```

---

## 📖 Документация

### После установки

```bash
# Запуск
~/.openclaw/start-deya.sh

# Или через systemd
sudo systemctl start deya-dashboard

# Просмотр логов
tail -f ~/.openclaw/logs/dashboard.log
```

### API

- `GET http://localhost:8001/` — Дашборд
- `WS http://localhost:8001/ws/chat` — WebSocket чат
- `GET http://localhost:8001/api/skills` — Список скиллов

### Настройка

Отредактируй `~/.openclaw/config.yaml`:

```yaml
model:
  default: "moonshot/kimi-k2.5"
  temperature: 0.7

instance:
  timezone: "Europe/Berlin"
```

---

## 🏗️ Для разработчиков

### Сборка скиллов

```bash
# Упаковать все скиллы
./scripts/package-skills.sh

# Создать релиз
./scripts/create-release.sh v1.1.0
```

### Docker

```bash
# Собрать образ
docker build -t deya/openclaw:latest .

# Запустить
docker run -p 8001:8001 deya/openclaw:latest
```

---

## 🛣️ Roadmap

- [x] Базовая персона (Deya Mode)
- [x] UI/UX генератор с GSAP
- [x] Инструменты разработчика
- [x] Web scraping
- [x] Визуальная айдентика
- [x] Веб-интерфейс
- [x] Система развёртывания
- [ ] Авторизация (JWT)
- [ ] Многопользовательский режим
- [ ] Интеграция с большим количеством каналов
- [ ] Мобильное приложение

---

## 🤝 Участие

PR и issues приветствуются! Смотри [CONTRIBUTING.md](CONTRIBUTING.md)

### Создание нового скилла

```bash
# Используй шаблон
cp -r skills/template skills/my-skill

# Отредактируй SKILL.md
# Добавь скрипты
# Упакуй
tar -czf my-skill-v1.0.skill my-skill/
```

---

## 📜 Лицензия

MIT License — свободное использование и модификация.

См. [LICENSE](LICENSE)

---

## 💬 Связь

- 🌐 Сайт: https://go.airouter.host
- 💬 Telegram: [@dayanrouter](https://t.me/dayanrouter)
- 🐙 GitHub: [@Mysense775](https://github.com/Mysense775)

---

<p align="center">
  <b>🌺 Создано с любовью Деей</b>
</p>
