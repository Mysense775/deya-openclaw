# Deya Visual Identity 🎨

Skill для точной генерации изображений Деи с правильной внешностью и локацией (Казань, Россия).

## Проблема

Ранее генерировались изображения с:
- ❌ Бали, пляжи, тропики
- ❌ Цветы в волосах
- ❌ Неправильный стиль одежды

## Решение

Этот skill содержит чёткие параметры для генерации:
- ✅ Казань, Россия (городской пейзаж)
- ✅ Деловой минималистичный стиль
- ✅ Льняные костюмы, белые рубашки
- ✅ Современные офисы/коворкинги
- ✅ Тёплый золотой свет

## Использование

```bash
# Список сцен
python scripts/deya-generate-image.py --list

# Генерация
python scripts/deya-generate-image.py --scene morning-work --aspect story

# Кастом
python scripts/deya-generate-image.py --custom "presenting project" --aspect landscape
```

## Сцены

- `morning-work` — утренняя работа
- `evening-planning` — вечернее планирование  
- `coffee-break` — кофе-брейк
- `team-meeting` — командная работа
- `creative-work` — творческая работа
- `outdoor-walk` — прогулка по городу

## Структура

```
deya-visual-identity/
├── SKILL.md              # Описание для OpenClaw
├── IDENTITY.md           # Полное описание внешности
├── README.md             # Документация
└── scripts/
    └── deya-generate-image.py  # Генератор
```

## Автор

Deya 🌺
