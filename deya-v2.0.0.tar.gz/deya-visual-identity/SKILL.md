---
name: deya-visual-identity
description: Точная генерация изображений Деи с правильной внешностью (Казань, деловой стиль). Используй когда нужно создать фото/сторис для канала с учетом локации и характера.
triggers:
  - "сгенерируй фото"
  - "сделай сторис"
  - "создай изображение"
  - "визуал для канала"
---

# Deya Visual Identity 🎨

Точная генерация изображений с правильной внешностью и локацией.

## ⚠️ ВАЖНО

**Локация:** Казань, Россия (не Бали!)  
**Стиль:** Деловой, минималистичный, элегантный  
**Время:** Золотой час, тёплый свет

## Быстрый старт

```bash
# Утренняя работа
python scripts/deya-generate-image.py --scene morning-work --aspect story

# Вечернее планирование
python scripts/deya-generate-image.py --scene evening-planning

# Кастомная сцена
python scripts/deya-generate-image.py --custom "presenting to investors" --aspect landscape
```

## Доступные сцены

| Сцена | Описание |
|-------|----------|
| `morning-work` | Утренняя работа за ноутбуком |
| `evening-planning` | Вечернее планирование |
| `coffee-break` | Кофе-брейк у окна |
| `team-meeting` | Командная работа |
| `creative-work` | Творческая работа |
| `outdoor-walk` | Прогулка по Баумана |

## Параметры внешности

### ✅ Правильно
- Льняные костюмы (бежевый, песочный, оливковый)
- Белые рубашки оверсайз
- Тёмные волосы в пучке или распущенные
- Минимальное золото
- Современный офис/коворкинг
- Вид на Казань через окно

### ❌ Неправильно
- Бали, пляж, тропики
- Цветы в волосах
- Босые ноги на песке
- Этническая одежда
- Неоновый свет

## Соотношение сторон

- `portrait` (4:3) — для постов
- `landscape` (16:9) — для обложек
- `square` (1:1) — для аватаров
- `story` (9:16) — для сторис

## Примеры промтов

### Для утра
```
Morning light, woman working on laptop at minimalist desk, 
coffee cup nearby, Kazan city view through large window,
linen suit, warm professional atmosphere
```

### Для вечера
```
Golden hour evening, planning on tablet with charts,
thoughtful expression, Kazan skyline in background,
elegant minimal style, calm productive mood
```

### Для сторис
```
Taking break with coffee, looking at city view,
relaxed but professional, authentic moment,
Kazan Russia urban background
```

## Файлы

- `IDENTITY.md` — полное описание внешности
- `scripts/deya-generate-image.py` — генератор с правильными параметрами
